import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import fs from "fs";
import config from "../config.json" assert { type: "json" };

export const data = new SlashCommandBuilder()
  .setName("aday-sil")
  .setDescription("Aday sil")
  .addStringOption(o =>
    o.setName("isim")
      .setDescription("Aday adı")
      .setRequired(true)
  );

// 🧾 LOG FONKSİYONU
async function sendLog(interaction, message) {
  if (!interaction.guild) return;
  if (!config.LOG_CHANNEL_ID) return;

  const channel = await interaction.guild.channels
    .fetch(config.LOG_CHANNEL_ID)
    .catch(() => null);

  if (!channel || !channel.isTextBased()) return;

  const time = new Date().toLocaleString("tr-TR", {
    dateStyle: "short",
    timeStyle: "medium"
  });

  channel.send(
    `🧾 **LOG**\n\n` +
    `👤 **Kullanıcı:** ${interaction.user.tag}\n` +
    `🆔 **ID:** ${interaction.user.id}\n` +
    `📌 **İşlem:** ${message}\n` +
    `⏰ **Tarih:** ${time}`
  );
}

export async function execute(interaction) {
  if (!interaction.member.roles.cache.has(config.RESULT_ROLE_ID)) {
    await sendLog(
      interaction,
      `Yetkisiz deneme → /aday-sil`
    );
    return interaction.reply({
      content: "❌ Yetkin yok",
      ephemeral: true
    });
  }

  const name = interaction.options.getString("isim");

  const db = JSON.parse(
    fs.readFileSync("./data/election.json", "utf8")
  );

  db.candidates = db.candidates.filter(c => c !== name);
  delete db.votes[name];

  fs.writeFileSync(
    "./data/election.json",
    JSON.stringify(db, null, 2)
  );

  // 🧾 LOG
  await sendLog(
    interaction,
    `Aday silindi → **${name}**`
  );

  // 🔴 KIRMIZI EMBED
  const embed = new EmbedBuilder()
    .setColor(0xED4245) // Discord kırmızısı
    .setTitle("🗑️ Aday Silindi")
    .setDescription(`**${name}** adaylıktan kaldırıldı`)
    .setFooter({
      text: `Silen: ${interaction.user.tag}`,
      iconURL: interaction.user.displayAvatarURL()
    })
    .setTimestamp();

  return interaction.reply({
    embeds: [embed]
  });
}
