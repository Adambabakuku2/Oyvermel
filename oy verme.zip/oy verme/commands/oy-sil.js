import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import fs from "fs";
import config from "../config.json" assert { type: "json" };

export const data = new SlashCommandBuilder()
  .setName("oy-sil")
  .setDescription("Adaydan oy sil")
  .addStringOption(o =>
    o.setName("aday")
      .setDescription("Aday adı")
      .setRequired(true)
  )
  .addIntegerOption(o =>
    o.setName("sayi")
      .setDescription("Silinecek oy")
      .setRequired(true)
  );

// 🧾 LOG FONKSİYONU
async function sendLog(interaction, message) {
  if (!interaction.guild) return;
  if (!config.LOG_CHANNEL_ID) return;

  const channel = await interaction.guild.channels
    .fetch(config.LOG_CHANNEL_ID)
    .catch(() => null);

  if (!channel || !channel.isTextBased()) return;

  const time = new Date().toLocaleString("tr-TR", {
    dateStyle: "short",
    timeStyle: "medium"
  });

  channel.send(
    `🧾 **LOG**\n\n` +
    `👤 **Kullanıcı:** ${interaction.user.tag}\n` +
    `🆔 **ID:** ${interaction.user.id}\n` +
    `📌 **İşlem:** ${message}\n` +
    `⏰ **Tarih:** ${time}`
  );
}

export async function execute(interaction) {
  // 🔐 Sadece OWNER
  if (interaction.user.id !== config.OWNER_ID) {
    await sendLog(
      interaction,
      `Yetkisiz deneme → /oy-sil`
    );
    return interaction.reply({
      content: "❌ Yetkin yok",
      ephemeral: true
    });
  }

  const aday = interaction.options.getString("aday");
  const sayi = interaction.options.getInteger("sayi");

  const db = JSON.parse(
    fs.readFileSync("./data/election.json", "utf8")
  );

  if (!db.votes[aday] || db.votes[aday] <= 0) {
    await sendLog(
      interaction,
      `Oy silme denemesi (oy yok) → ${aday}`
    );
    return interaction.reply({
      content: `❌ **${aday}** için silinecek oy yok`,
      ephemeral: true
    });
  }

  const before = db.votes[aday];

  // 🧮 Negatif engel
  db.votes[aday] -= sayi;
  if (db.votes[aday] < 0) db.votes[aday] = 0;

  const after = db.votes[aday];

  fs.writeFileSync(
    "./data/election.json",
    JSON.stringify(db, null, 2)
  );

  await sendLog(
    interaction,
    `Manuel oy silindi → **${aday}** (-${sayi}) | ${before} → ${after}`
  );

  // 🔵 KOYU MAVİ EMBED
  const embed = new EmbedBuilder()
    .setColor(0x2B2D31) // koyu mavi / koyu discord tonu
    .setTitle("🗑️ Oy Silindi")
    .addFields(
      { name: "👤 Aday", value: aday, inline: true },
      { name: "➖ Silinen Oy", value: sayi.toString(), inline: true },
      { name: "📊 Güncel Oy", value: after.toString(), inline: true }
    )
    .setFooter({
      text: `İşlemi yapan: ${interaction.user.tag}`,
      iconURL: interaction.user.displayAvatarURL()
    })
    .setTimestamp();

  return interaction.reply({
    embeds: [embed]
  });
}
