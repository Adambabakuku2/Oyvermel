import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import fs from "fs";
import config from "../config.json" assert { type: "json" };

export const data = new SlashCommandBuilder()
  .setName("oy-ekle")
  .setDescription("Adaya oy ekle")
  .addStringOption(o =>
    o.setName("aday")
      .setDescription("Aday adı")
      .setRequired(true)
  )
  .addIntegerOption(o =>
    o.setName("sayi")
      .setDescription("Eklenecek oy")
      .setRequired(true)
  );

// 🧾 LOG FONKSİYONU
async function sendLog(interaction, message) {
  if (!interaction.guild) return;
  if (!config.LOG_CHANNEL_ID) return;

  const channel = await interaction.guild.channels
    .fetch(config.LOG_CHANNEL_ID)
    .catch(() => null);

  if (!channel || !channel.isTextBased()) return;

  const time = new Date().toLocaleString("tr-TR", {
    dateStyle: "short",
    timeStyle: "medium"
  });

  channel.send(
    `🧾 **LOG**\n\n` +
    `👤 **Kullanıcı:** ${interaction.user.tag}\n` +
    `🆔 **ID:** ${interaction.user.id}\n` +
    `📌 **İşlem:** ${message}\n` +
    `⏰ **Tarih:** ${time}`
  );
}

export async function execute(interaction) {
  if (interaction.user.id !== config.OWNER_ID) {
    await sendLog(
      interaction,
      `Yetkisiz deneme → /oy-ekle`
    );
    return interaction.reply({
      content: "❌ Yetkin yok",
      ephemeral: true
    });
  }

  const aday = interaction.options.getString("aday");
  const sayi = interaction.options.getInteger("sayi");

  const db = JSON.parse(
    fs.readFileSync("./data/election.json", "utf8")
  );

  if (!db.votes[aday]) db.votes[aday] = 0;
  db.votes[aday] += sayi;

  fs.writeFileSync(
    "./data/election.json",
    JSON.stringify(db, null, 2)
  );

  await sendLog(
    interaction,
    `Manuel oy eklendi → **${aday}** (+${sayi})`
  );

  // 🔹 AÇIK MAVİ EMBED
  const embed = new EmbedBuilder()
    .setColor(0x5DADEC) // açık mavi
    .setTitle("➕ Oy Eklendi")
    .addFields(
      { name: "👤 Aday", value: aday, inline: true },
      { name: "➕ Eklenen Oy", value: sayi.toString(), inline: true },
      { name: "📊 Toplam Oy", value: db.votes[aday].toString(), inline: true }
    )
    .setFooter({
      text: `İşlemi yapan: ${interaction.user.tag}`,
      iconURL: interaction.user.displayAvatarURL()
    })
    .setTimestamp();

  return interaction.reply({
    embeds: [embed]
  });
}
