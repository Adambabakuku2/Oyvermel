import { SlashCommandBuilder } from "discord.js";
import fs from "fs";
import config from "../config.json" assert { type: "json" };

export const data = new SlashCommandBuilder()
  .setName("bitir")
  .setDescription("Seçimi bitir ve sıfırla");

export async function execute(interaction) {
  // ⏳ Discord bekle
  await interaction.deferReply();

  if (interaction.user.id !== config.OWNER_ID) {
    return interaction.editReply("❌ Yetkin yok");
  }

  const empty = {
    active: false,
    candidates: [],
    votes: {},
    voters: {}
  };

  fs.writeFileSync(
    "./data/election.json",
    JSON.stringify(empty, null, 2)
  );

  await interaction.editReply("🔁 Seçim bitirildi ve tüm veriler sıfırlandı");
}
