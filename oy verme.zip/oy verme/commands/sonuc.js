import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import fs from "fs";
import config from "../config.json" assert { type: "json" };

export const data = new SlashCommandBuilder()
  .setName("sonuc")
  .setDescription("Seçim sonuçları");

export async function execute(interaction) {
  // ⏳ Discord'a "bekle" de
  await interaction.deferReply({ ephemeral: false });

  if (!interaction.member.roles.cache.has(config.RESULT_ROLE_ID)) {
    return interaction.editReply({ content: "❌ Yetkin yok" });
  }

  const db = JSON.parse(fs.readFileSync("./data/election.json", "utf8"));
  const total = Object.values(db.votes).reduce((a, b) => a + b, 0);

  const sorted = [...db.candidates].sort(
    (a, b) => (db.votes[b] || 0) - (db.votes[a] || 0)
  );

  const medals = ["🥇", "🥈", "🥉"];
  let desc = `**🗳️ ATILAN TOPLAM OY:** ${total}\n\n`;

  sorted.forEach((c, i) => {
    const v = db.votes[c] || 0;
    const p = total ? (v / total) * 100 : 0;

    const barLength = 20;
    const filled = Math.round((p / 100) * barLength);
    const bar = "🟦".repeat(filled) + "⬛".repeat(barLength - filled);

    const medal = medals[i] || "🔹";
    const winner = i === 0 && total > 0 ? " 🏆 **KAZANAN**" : "";

    desc += `${medal} **${c}**${winner}\n`;
    desc += `Oy: **${v}** | Oran: **%${p.toFixed(1)}**\n`;
    desc += `${bar}\n\n`;
  });

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setTitle("📊 SEÇİM SONUÇLARI")
        .setDescription(desc)
        .setColor(0x0B3C5D)
        .setTimestamp()
    ]
  });
}