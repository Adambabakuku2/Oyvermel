import {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder
} from "discord.js";
import fs from "fs";
import config from "../config.json" assert { type: "json" };

export const data = new SlashCommandBuilder()
  .setName("baslat")
  .setDescription("Seçimi başlat");

export async function execute(interaction) {
  // ⏳ Discord’u beklemeye al
  await interaction.deferReply();

  if (interaction.user.id !== config.OWNER_ID) {
    return interaction.editReply("❌ Yetkin yok");
  }

  const db = JSON.parse(fs.readFileSync("./data/election.json"));

  if (db.active) {
    return interaction.editReply("⚠️ Seçim zaten aktif");
  }

  db.active = true;

  const menu = new StringSelectMenuBuilder()
    .setCustomId("vote")
    .setPlaceholder("🗳️ Oy ver")
    .addOptions(
      db.candidates.map(c => ({
        label: c,
        value: c
      }))
    );

  fs.writeFileSync("./data/election.json", JSON.stringify(db, null, 2));

  await interaction.editReply({
    embeds: [
      new EmbedBuilder()
        .setTitle("🗳️ Seçim Başladı")
        .setDescription("Aşağıdaki menüden oyunuzu kullanabilirsiniz")
        .setColor(0x1f8bff)
    ],
    components: [
      new ActionRowBuilder().addComponents(menu)
    ]
  });
}