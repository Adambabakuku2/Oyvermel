import { SlashCommandBuilder, EmbedBuilder } from "discord.js";
import fs from "fs";
import config from "../config.json" assert { type: "json" };

export const data = new SlashCommandBuilder()
  .setName("aday")
  .setDescription("Aday ekle")
  .addStringOption(o =>
    o.setName("isim")
      .setDescription("Aday adı")
      .setRequired(true)
  );

// 🧾 LOG FONKSİYONU
async function sendLog(interaction, message) {
  if (!interaction.guild) return;
  if (!config.LOG_CHANNEL_ID) return;

  const channel = await interaction.guild.channels
    .fetch(config.LOG_CHANNEL_ID)
    .catch(() => null);

  if (!channel || !channel.isTextBased()) return;

  const time = new Date().toLocaleString("tr-TR", {
    dateStyle: "short",
    timeStyle: "medium"
  });

  channel.send(
    `🧾 **LOG**\n\n` +
    `👤 **Kullanıcı:** ${interaction.user.tag}\n` +
    `🆔 **ID:** ${interaction.user.id}\n` +
    `📌 **İşlem:** ${message}\n` +
    `⏰ **Tarih:** ${time}`
  );
}

export async function execute(interaction) {
  const name = interaction.options.getString("isim");

  const db = JSON.parse(
    fs.readFileSync("./data/election.json", "utf8")
  );

  // 🔓 Direkt ekler (kontrol yok)
  db.candidates.push(name);

  fs.writeFileSync(
    "./data/election.json",
    JSON.stringify(db, null, 2)
  );

  // 🧾 LOG
  await sendLog(
    interaction,
    `Aday eklendi → **${name}**`
  );

  // ✅ YEŞİL EMBED
  const embed = new EmbedBuilder()
    .setColor(0x57F287) // Discord yeşili
    .setTitle("✅ Aday Eklendi")
    .setDescription(`**${name}** başarıyla aday listesine eklendi`)
    .setFooter({
      text: `Ekleyen: ${interaction.user.tag}`,
      iconURL: interaction.user.displayAvatarURL()
    })
    .setTimestamp();

  return interaction.reply({
    embeds: [embed]
  });
}
