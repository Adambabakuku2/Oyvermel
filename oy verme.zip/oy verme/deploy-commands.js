import { REST, Routes } from "discord.js";
import fs from "fs";
import config from "./config.json" assert { type: "json" };

const commands = [];

const commandFiles = fs
  .readdirSync("./commands")
  .filter(file => file.endsWith(".js"));

for (const file of commandFiles) {
  const cmd = await import(`./commands/${file}`);

  // 🛡️ Güvenlik kontrolü
  if (!cmd.data || !cmd.execute) {
    console.log(`⏭️ Atlandı (slash değil): ${file}`);
    continue;
  }

  commands.push(cmd.data.toJSON());
}

const rest = new REST({ version: "10" }).setToken(config.token);

await rest.put(
  Routes.applicationGuildCommands(
    config.clientId,
    config.guildId
  ),
  { body: commands }
);

console.log("✅ Slash komutlar yüklendi");
