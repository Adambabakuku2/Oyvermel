export async function sendLog(client, config, title, description) {
  try {
    const channel = await client.channels.fetch(config.LOG_CHANNEL_ID);
    if (!channel) return;

    await channel.send({
      embeds: [
        {
          title,
          description,
          color: 0x2C3E50,
          timestamp: new Date()
        }
      ]
    });
  } catch (err) {
    console.error("LOG GÖNDERİLEMEDİ:", err.message);
  }
}
