import {
  Client,
  GatewayIntentBits,
  Collection,
  EmbedBuilder
} from "discord.js";
import fs from "fs";
import config from "./config.json" assert { type: "json" };

const client = new Client({
  intents: [GatewayIntentBits.Guilds]
});

client.commands = new Collection();

/* KOMUTLAR */
for (const file of fs.readdirSync("./commands")) {
  const command = await import(`./commands/${file}`);
  client.commands.set(command.data.name, command);
}

/* INTERACTIONS */
client.on("interactionCreate", async interaction => {
  try {
    // SLASH KOMUT
    if (interaction.isChatInputCommand()) {
      const cmd = client.commands.get(interaction.commandName);
      if (!cmd) return;
      await cmd.execute(interaction);
    }

    // 🗳️ OYLAMA
    if (interaction.isStringSelectMenu()) {
      if (interaction.customId !== "vote") return;

      await interaction.deferReply({ ephemeral: true });

      const db = JSON.parse(
        fs.readFileSync("./data/election.json", "utf8")
      );

      if (!db.active)
        return interaction.editReply("⛔ Seçim bitmiş");

      if (db.voters[interaction.user.id])
        return interaction.editReply("❌ Zaten oy kullandın");

      const choice = interaction.values[0];

      db.votes[choice] = (db.votes[choice] || 0) + 1;
      db.voters[interaction.user.id] = {
        choice,
        time: Date.now()
      };

      fs.writeFileSync(
        "./data/election.json",
        JSON.stringify(db, null, 2)
      );

      // 🧾 LOG KANALI → AÇIK SARI EMBED
      if (interaction.guild && config.LOG_CHANNEL_ID) {
        const logChannel = await interaction.guild.channels
          .fetch(config.LOG_CHANNEL_ID)
          .catch(() => null);

        if (logChannel && logChannel.isTextBased()) {
          const embed = new EmbedBuilder()
            .setTitle("🗳️ Oy Kullanıldı")
            .setColor(0xF9E547) // 🟡 Açık sarı
            .addFields(
              { name: "👤 Kullanıcı", value: `${interaction.user.tag}` },
              { name: "🆔 ID", value: interaction.user.id },
              { name: "📌 Oy Verilen", value: choice }
            )
            .setFooter({
              text: "Seçim Sistemi"
            })
            .setTimestamp();

          await logChannel.send({ embeds: [embed] });
        }
      }

      // ✅ KULLANICIYA NORMAL CEVAP
      return interaction.editReply(
        `✅ Oyun başarıyla kaydedildi (**${choice}**)`
      );
    }

  } catch (err) {
    console.error("INTERACTION ERROR:", err);
    if (interaction.deferred || interaction.replied) {
      interaction.editReply("❌ Bir hata oluştu");
    }
  }
});

client.login(config.token);
